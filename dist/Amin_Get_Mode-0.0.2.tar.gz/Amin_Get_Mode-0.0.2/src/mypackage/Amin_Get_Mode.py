numb = float(input("Ent A Numb: "))
if numb % 2 == 0:
    print("The numb it is - even")
else:
    print("The numb it is - odd")    